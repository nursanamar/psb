<?php 
	include 'cone.php';
	include 'randpass.php';
	mysql_select_db('psb')
 ?>
<?php echo "'",hitungjrsn('TKJ'),"',"; ?>