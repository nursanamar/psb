<?php 
	include 'cone.php';
	
	if (isset($_FILES['file'])) {
		include 'excel_reader2.php';
		$data = new Spreadsheet_Excel_Reader($_FILES['file']['tmp_name']);
		$baris = $data->rowcount($sheet_index=0);
		$sukses=0;
		$gagal=0;
		$r=2;
		for ($i=1; $i < $baris ; $i++) { 
			$id_csba=$data->val($r,1);
			$jurusan=$data->val($r,2);
			$qu="INSERT INTO csbalulus VALUES('$id_csba','$jurusan')";
			$masuk=mysqli_query($sambung,$qu) or die(mysqli_error($sambung));
			if ($masuk) {
				$sukses++;
			} else {
				$gagal++;
			}
			$r++;
			
		}
		echo "sukses :",$sukses,"<br>","gagal",$gagal;
		echo $baris;
	}else{
		echo "<script type='text/javascript'>window.location='datalulus.php'</script>";
	}
	

 ?>