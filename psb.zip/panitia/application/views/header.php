<?php 
  echo "<nav class='navbar navbar-inverse navbar-fixed-top'>
      <div class='container'>
        <div class='navbar-header'>
          <a class='navbar-brand' href='#menu-toggle' id='menu-toggle' onclick='togel()'><span class='glyphicon glyphicon-list' aria-hidden='true'></span></a>
          <div class='navbar-brand'>
            Dashboard Staff
          </div>
        </div>
        <!--/.nav-collapse -->
      </div>
    </nav>";
 ?>