<?php 
	echo now();
 ?>